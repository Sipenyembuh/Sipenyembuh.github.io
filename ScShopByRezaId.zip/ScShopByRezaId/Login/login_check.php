<?php 
//menerima POST username dan password
$username = trim($_POST['username']);
$password = trim($_POST['password']);

//Jika username dan password adalah admin maka daftarkan session
if($username == 'shop' && $password == 'shop') {

	//daftarkan session
	session_start();
	$_SESSION['username'] = 'admin';

	//redirect ke halaman content
	header('location:content.php');
} else {

	//jika username dan password tidak cocok, maka kembali ke halaman index.php
	header('location:index.php');
}
?>