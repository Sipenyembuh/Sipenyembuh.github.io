<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Clash Of Store</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/maincyber.css">
<script src="js/jquery.min.js"></script>
<script src="http://supercellchange-name.tk/library/js/bootstrap.min.js"></script>
</head>
<script type='text/javascript'>
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="shafou.com"});
//]]>
</script>
<body>
<div class="container yozora">
<div  class="col-md-12 yozora">
<div class="well well-sm yozora">
<!--img style="border:1px solid #f1f1f1" class="yozora-logo" src="images/header.png"/-->
<nav  class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><i class="fa fa-shopping-bag"></i> Clash Of Store</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Beranda</a></li>
<li class="active"><a href="#">Order Web Phising</a>
<li class="active"><a href="#">Order Script Phising</a>
      </ul>
      <ul class="nav navbar-nav navbar-right">
<li><a href="http://supercellchange-name.tk/Login/"><i class="fa fa-lock"></i> Admin Panel</a></li>
        <li><a href="https://www.facebook.com/AnonyXmakerz"><i class="fa fa-phone"></i> Contact</a></li>
      </ul>
    </div>
  </div>
</nav></div>
<!-- opsional doang bro
<ul class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ul>-->
<div style="background:white;margin-top:0;border:1px solid #f1f1f1" class="col-md-12"><div class="row"><p></p>

<p></p>
  <div class="col-md-4">
<div class="panel panel-default">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/ppim.png"/></div>
  <div class="panel-body">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/baseim.png"/></div>
  <div class="panel-body"></div>
<br/>
  <center>							
	<h4 style="color:#2780e3"><b>TH 8 Prematur <br>Device Aman<br>CN ON</b></h4>
  <h4 >Harga : Rp 30.000</h4>
				<a href="https://www.facebook.com/AnonyXmakerz" class="btn btn-primary btn-block">BELI</a>	</center>			 							 
    
	<!--END Bagian Detail-->
</div>
  </div>
</div>
  <div class="col-md-4">
<div class="panel panel-default">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/ppkalam.png"/></div>
  <div class="panel-body">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/basekalam.png"/></div>
  <div class="panel-body"></div>
<br/>
  <center>							
	<h4 style="color:#2780e3"><b>TH 9 MAX Kecuali WALL <br> Device Aman <br>CN ON</b></h4>
  <h4 >Harga : Rp 110.000</h4>
				<a href="https://www.facebook.com/AnonyXmakerz" class="btn btn-primary btn-block">BELI</a>	</center>			 							 
    
	<!--END Bagian Detail-->
</div>
  </div>
</div>
  <div class="col-md-4">
<div class="panel panel-default">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/ppspyro.png"/></div>
  <div class="panel-body">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/basespyro.png"/></div>
  <div class="panel-body"></div>
<br/>
  <center>							
	<h4 style="color:#2780e3"><b>TH 9 Semi Max <br>Device Aman<br>CN OFF</b></h4>
  <h4 >Harga : Rp 110.000</h4>
				<a href="https://www.facebook.com/AnonyXmakerz" class="btn btn-primary btn-block">BELI</a>	</center>			 							 
    
	<!--END Bagian Detail-->
</div>
  </div>
</div>
  <div class="col-md-4">
<div class="panel panel-default">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/pppolo.png"/></div>
  <div class="panel-body">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/basepolo.png"/></div>
  <div class="panel-body"></div>
<br/>
  <center>							
	<h4 style="color:#2780e3"><b>TH 9 Prematur <br>Device Aman <br>CN OFF</b></h4>
  <h4 >Harga : Rp 80.000</h4>
				<a href="https://www.facebook.com/AnonyXmakerz" class="btn btn-primary btn-block">BELI</a>	</center>			 							 
    
	</div>
  </div>
</div>
  <div class="col-md-4">
<div class="panel panel-default">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/sold.png"/></div>
  <div class="panel-body">
  <div class="panel-heading yozora"><img style="border:1px solid #f1f1f1" class="yozora-img" src="image/sold.png"/></div>
  <div class="panel-body"></div>
<br/>
  <center>							
	<h4 style="color:#2780e3"><b>TH 9 Max <br>Device Aman<br>CN OFF</b></h4>
  <h4 >Harga : Rp - </h4>
				<a href="https://www.facebook.com/AnonyXmakerz" class="btn btn-primary btn-block">SOLD</a>	</center>			 							 
    
	<!--END Bagian Detail-->
</div>     <!--Bagian Detal-->

</div>
</div>

</div>

		<hr>
		<div class="container">
		<footer>
        <div class="row">
          <div class="col-lg-12">
                     <div class="col-lg-12"><br>
            
            <center><a href="http://supercellchange-name.tk" class="btn">Copyright &copy;2016</a>
<a href="" class="btn">CLASH OF STORE</a>
			</center>   
          </div></body>	
</html>